import express from 'express';
import { isAuth, logout, register, userLogin } from '../controllers/userController.js';
import authUser from '../middlewares/authUser.js';

const userRouter = express.Router();

userRouter.post('/register', register);
userRouter.post('/login', userLogin)
userRouter.get('/is-auth', authUser, isAuth);
userRouter.get('/logout', authUser, logout)

export default userRouter;